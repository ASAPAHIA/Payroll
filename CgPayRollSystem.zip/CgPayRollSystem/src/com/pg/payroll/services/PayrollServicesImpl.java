package com.pg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.pg.payroll.daoservices.AssociateDAO;
import com.pg.payroll.daoservices.AssociateDAOImpl;

public class PayrollServicesImpl implements PayrollServices{
	private AssociateDAO associateDao;
	public PayrollServicesImpl() {
		
	
		associateDao=new AssociateDAOImpl();
	}
	public  PayrollServicesImpl (AssociateDAO associateDao)
	{
		super();
		this .associateDao=associateDao;
	}
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountnumber, String bankName, String ifscCode) {


		BankDetails bankDetails=new BankDetails(accountnumber,bankName,ifscCode);
		Salary salary=new Salary(basicSalary, epf,  companyPf);
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId,salary,bankDetails);
		associate=associateDao.save(associate);

		return associate.getAssociateId();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailNotfoundException {
		Associate associate=getAssociateDetails(associateId);
		int netSalary=0;
		if(associate==null)
			throw new AssociateDetailNotfoundException("Associate Detail Notfound Exception"+associateId);
		else
		{
			int basicSal=associate.getSal().getBasicSalary();
			int monthlyGrossSal=(int)(basicSal+(basicSal*0.7));
			int annualGrossSalary=12*monthlyGrossSal;
			int investment=associate.getYearlyInvestmentUnder80C()+associate.getSal().getEpf()+associate.getSal().getCompanyPf();
			if(investment>=150000)
				investment=150000;
			if(annualGrossSalary<250000)
				netSalary=annualGrossSalary-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
			else if(annualGrossSalary>=250000&&annualGrossSalary<500000)
				netSalary=annualGrossSalary-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
			else if(annualGrossSalary>=500000&&annualGrossSalary<1000000) {
				int tax1 = (int)((annualGrossSalary-500000)*0.2);
				int tax2=(int)((annualGrossSalary-250000)*0.1);
				netSalary=annualGrossSalary-associate.getSal().getEpf()-associate.getSal().getCompanyPf()-tax1-tax2;}
			else if(annualGrossSalary>1000000) {
				int tax3=(int)((annualGrossSalary-1000000)*0.3);
				int tax2=100000;
				int tax1=(int)((250000-investment)*0.1);
				netSalary=annualGrossSalary-tax1-tax2-tax3-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
			}
		}
		return netSalary;
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailNotfoundException {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailNotfoundException("Associate Detail Not found for="+associateId);
		return associate;
	}

	@Override
	public List<Associate> getAllAssociateDetails() {

		return associateDao.findAll();
	}

}
