package com.cg.payroll.client;

import com.cg.payroll.util.PayrollDBUtil;
import com.pg.payroll.services.PayrollServices;
import com.pg.payroll.services.PayrollServicesImpl;

public class MainClass
{
public static void main(String args[])
{
	PayrollServices services=new PayrollServicesImpl();
	int associateId=services.acceptAssociateDetails("abhi", "sapahia", "abhi@gmail.com", "sddsf", "1900", "qwerty", 1000, 6000, 100, 1000, 123456789, "axis", "axis00n");
int associateId2=services.acceptAssociateDetails("abhi", "sap", "ab@gmail.com", "sdd", "1400", "qwer", 10000, 5000, 100, 1000, 123456789, "axis", "axis00n");
	System.out.println(PayrollDBUtil.associates.get(associateId));
	System.out.println(PayrollDBUtil.associates.get(associateId2));

	System.out.println("net salary of E1="+	services.calculateNetSalary(associateId));

	System.out.println("net salary of E2="+	services.calculateNetSalary(associateId2));

}
}
