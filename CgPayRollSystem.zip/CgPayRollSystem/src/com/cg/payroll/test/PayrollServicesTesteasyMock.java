package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.pg.payroll.daoservices.AssociateDAO;
import com.pg.payroll.services.PayrollServices;
import com.pg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTesteasyMock {
public static  PayrollServices payrollServices;
public static AssociateDAO mockAssociateDao;

@BeforeClass
public static void setUpTestEnv()
{
	mockAssociateDao=EasyMock.mock(AssociateDAO.class);
	payrollServices=new PayrollServicesImpl(mockAssociateDao);
}

@Before
public void setUpTestmockData()
{
	Associate associate1=new Associate(101,78000,"abhi","sapahia","a8","analyst","DTDYF736",
			"abhi@gmail.com",new Salary(35000,1800,200),new BankDetails(12345,"PNB","qwerty"));
	
	Associate associate2=new Associate(101,78000,"ak","hia","a4","lyst","F736",
			"abhi0000@gmail.com",new Salary(35000,600,200),new BankDetails(12345,"PNB","qwerty"));
	
	Associate associate3=new Associate(58000,"abhi","sapa","a4","ana","DYF736",
			"abhi234@gmail.com",new Salary(45000,5000,200),new BankDetails(12345,"P","qwe"));
	
	ArrayList<Associate>associateList=new ArrayList<>();
	associateList.add(associate1);
	associateList.add(associate2);
	EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
	
	EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
	EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
	EasyMock.expect(mockAssociateDao.findOne(134465)).andReturn(null);
	EasyMock.expect(mockAssociateDao.findAll()).andReturn(associateList);
	EasyMock.replay(mockAssociateDao);
	
}
@Test(expected=AssociateDetailNotfoundException.class)
public void testGetAssociateDataForInvalidAssociateId()throws AssociateDetailNotfoundException{
	payrollServices.getAssociateDetails(1234);
	EasyMock.verify(mockAssociateDao.findOne(1234));
}
@Test
public void testGetAssociateDataForValidAssociateId()throws AssociateDetailNotfoundException{

Associate expectedAssociate=new Associate(101,78000,"abhi","sapahia","a8","analyst","DTDYF736",
		"abhi@gmail.com",new Salary(35000,1800,200),new BankDetails(12345,"PNB","qwerty"));
Associate actualAssociate=payrollServices.getAssociateDetails(101);
assertEquals(expectedAssociate,actualAssociate);
EasyMock.verify(mockAssociateDao.findOne(101));
}
@After
public void tearDownTestMockData() {
	EasyMock.resetToDefault(mockAssociateDao);
}
@AfterClass
public static void tearDownTestEnv() {
	mockAssociateDao=null;
	payrollServices=null;
}

}
